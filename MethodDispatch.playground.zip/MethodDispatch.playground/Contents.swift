protocol Movable{
    
    // uncommenting  make this func table dispatch and executes is from Animal class (run time)
    // for now it is using Direct Dispatch
    //func walk()
    func crawl()
}
extension Movable{
    func walk() {
        print("walking from extension")
    }
}

struct Animal : Movable{
    func walk() {
        print("walking from Animal")
    }
    func crawl() {
        print("Crawling from Animal ")
    }
    
}

var animalObj : Animal = Animal()
animalObj.walk()
animalObj.crawl()

var movableObj : Movable = Animal()
movableObj.walk()
movableObj.crawl()

