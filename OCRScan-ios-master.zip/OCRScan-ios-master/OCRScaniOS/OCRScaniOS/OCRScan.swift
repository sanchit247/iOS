//
//  OCRScan.swift
//  OCRScaniOS
//
//  Created by Aadhar Mathur on 24/11/19.
//  Copyright © 2019 Aadhar Mathur. All rights reserved.
//

import Vision
import AVFoundation

fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

fileprivate func >= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l >= r
    default:
        return !(lhs < rhs)
    }
}

///The characters the globalNetwork can recognize.
///It **must** be in the **same order** as the network got trained
public var recognizableCharacters = "[A-Z0-9]{4}(-[A-Z0-9]{4}){3}"
///The FFNN network used for OCR
public var globalNetwork = FFNN.fromFile(Bundle(for: OCRScan.self).url(forResource: "OCR-Network", withExtension: nil)!)!

open class OCRScan {
     fileprivate        var characters = recognizableCharacters
      
      private  var strValue : String = ""
      private var strArr : [String] = []
      private var strValue1 : String = ""
    //  fileprivate     var network = globalNetwork
      
      //MARK: Setup
      
      ///SwiftOCR's delegate
      open weak var delegate: OCRScanDelegate?
      
      ///Radius in x axis for merging blobs
      open      var xMergeRadius:CGFloat = 1
      ///Radius in y axis for merging blobs
      open      var yMergeRadius:CGFloat = 3
      
      ///Only recognize characters on White List
      open      var characterWhiteList: String? = nil
      ///Don't recognize characters on Black List
      open      var characterBlackList: String? = nil
      
      ///Confidence must be bigger than the threshold
      open      var confidenceThreshold:Float = 0.1
      
      //MARK: Recognition data
      
      ///All SwiftOCRRecognizedBlob from the last recognition
      open      var currentOCRRecognizedBlobs = [OCRScanRecognizedBlob]()
      
      
      //MARK: Init
      public   init(){}
      
      public   init(recognizableCharacters: String) {
          self.characters = recognizableCharacters
          //self.network = network
      }
      
      public   init(image: OCRImage, delegate: OCRScanDelegate?, _ completionHandler: @escaping (String) -> Void){
          self.delegate = delegate
          self.recognize(image, completionHandler)
      }
      
      public   init(recognizableCharacters: String, image: OCRImage, delegate: OCRScanDelegate?, _ completionHandler: @escaping (String) -> Void) {
          self.characters = recognizableCharacters
       //   self.network = network
          self.delegate = delegate
          self.recognize(image, completionHandler)
      }
      
      /**
       
       Performs ocr on the image.
       
       - Parameter image:             The image used for OCR
       - Parameter completionHandler: The completion handler that gets invoked after the ocr is finished.
       
       */
      
      open   func recognize(_ image: OCRImage, _ completionHandler: @escaping (String) -> Void){
          
          func indexToCharacter(_ index: Int) -> Character {
              return Array(characters)[index]
          }
          
          func checkWhiteAndBlackListForCharacter(_ character: Character) -> Bool {
              let whiteList =   characterWhiteList?.contains(character) ?? true
              let blackList = !(characterBlackList?.contains(character) ?? false)
              
              return whiteList && blackList
          }
          DispatchQueue.global(qos: .userInitiated).async {
              var recognizedString       = ""
              let request = VNRecognizeTextRequest { request, error in
                  guard let observations = request.results as? [VNRecognizedTextObservation] else {
                      fatalError("Received invalid obserations")
                  }
                  for observation in observations {
                      guard let bestCandidate = observation.topCandidates(1).first else {
                          fatalError("No candidate")
                          continue
                      }
                     // print("Found this candidate \(bestCandidate.string)")
                      self.strValue = bestCandidate.string
                     // print(self.strValue)
                    if self.strValue.containsSpecialCharacter {
                        recognizedString = self.strValue
                      //  print(recognizedString)
                        completionHandler(recognizedString)
                        break
                    }else {
                        print("Wrong String")
                        recognizedString = "Wrong String....Scan Again"
                        completionHandler("Wrong Input")
                    }
                  }
                  

              }
              request.recognitionLevel = .accurate
              let requests = [request]
              DispatchQueue.global(qos: .userInitiated).async {
                  guard let img = image.cgImage else {
                      fatalError("Missing image to scan")
                  }
                  let handler  = VNImageRequestHandler(cgImage: img, options: [:])
                  try? handler.perform(requests)
                
              }
                    
                }
            }
      /**
       
       Performs ocr on the image in a specified rect.
       
       - Parameter image:             The image used for OCR
       - Parameter rect:              The rect in which recognition should take place.
       - Parameter completionHandler: The completion handler that gets invoked after the ocr is finished.
       
       */
    
    fileprivate func successfull() {
        print("Scan Successfull")
    }
      
      open   func recognizeInRect(_ image: OCRImage, rect: CGRect, completionHandler: @escaping (String) -> Void){
          DispatchQueue.global(qos: .userInitiated).async {
              #if os(iOS)
                  let cgImage        = image.cgImage
                  let croppedCGImage = cgImage?.cropping(to: rect)!
                  let croppedImage   = OCRImage(cgImage: croppedCGImage!)
              #else
                  let cgImage        = image.cgImage(forProposedRect: nil, context: nil, hints: nil)!
                  let croppedCGImage = cgImage.cropping(to: rect)!
                  let croppedImage   = OCRImage(cgImage: croppedCGImage, size: rect.size)
              #endif
              
              self.recognize(croppedImage, completionHandler)
              
          }
      }
}

// MARK: OCRScanDelegate

public protocol OCRScanDelegate: class {
    
    /**
     
     Implement this method for a custom image preprocessing algorithm. Only return a binary image.
     
     - Parameter inputImage: The image to preprocess.
     - Returns:              The preprocessed, binarized image that SwiftOCR should use for OCR. If you return nil SwiftOCR will use its default preprocessing algorithm.
     
     */
    
    func preprocessImageForOCR(_ inputImage: OCRImage) -> OCRImage?
    
}

extension OCRScanDelegate {
    func preprocessImageForOCR(_ inputImage: OCRImage) -> OCRImage? {
        return nil
    }
}

// MARK: SwiftOCRRecognizedBlob

public struct OCRScanRecognizedBlob {
    
    public let charactersWithConfidence: [(character: Character, confidence: Float)]!
    public let boundingBox:              CGRect!
    
    init(charactersWithConfidence: [(character: Character, confidence: Float)]!, boundingBox: CGRect) {
        self.charactersWithConfidence = charactersWithConfidence.sorted(by: { $0.confidence > $1.confidence })
        self.boundingBox = boundingBox
    }
    
}

extension String {
    
    //[A-Z0-9]{4}(-[A-Z0-9]{4}){3}
    
    var containsSpecialCharacter: Bool {
       let regex = "[A-Z0-9]{4}(-[A-Z0-9]{4}){3}"
       let testString = NSPredicate(format:"SELF MATCHES %@", regex)
       return testString.evaluate(with: self)
    }
    
    func isAlphanumeric() -> Bool {
        return self.rangeOfCharacter(from: CharacterSet.alphanumerics.inverted) == nil && self != ""
    }

    func isAlphanumeric(ignoreDiacritics: Bool = false) -> Bool {
        if ignoreDiacritics {
            return self.range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil && self != ""
        }
        else {
            return self.isAlphanumeric()
        }
    }
}

