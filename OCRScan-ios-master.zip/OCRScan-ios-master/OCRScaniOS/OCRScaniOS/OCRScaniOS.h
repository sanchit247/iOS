//
//  OCRScaniOS.h
//  OCRScaniOS
//
//  Created by Aadhar Mathur on 24/11/19.
//  Copyright © 2019 Aadhar Mathur. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for OCRScaniOS.
FOUNDATION_EXPORT double OCRScaniOSVersionNumber;

//! Project version string for OCRScaniOS.
FOUNDATION_EXPORT const unsigned char OCRScaniOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OCRScaniOS/PublicHeader.h>


