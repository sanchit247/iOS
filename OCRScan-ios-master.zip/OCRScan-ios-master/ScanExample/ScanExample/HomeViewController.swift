//
//  HomeViewController.swift
//  ScanExample
//
//  Created by sanchit on 26/11/19.
//  Copyright © 2019 Aadhar Mathur. All rights reserved.
//

import UIKit
var scratchCode = ""
class HomeViewController: UIViewController {

    @IBOutlet weak var labelScratchCode: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        labelScratchCode.layer.borderColor = UIColor.darkGray.cgColor;
        labelScratchCode.layer.borderWidth = 3.0;
    }
    override func viewWillAppear(_ animated: Bool) {
        if scratchCode != "" {
            self.labelScratchCode.text = scratchCode
        }
    }
    
    @IBAction func continuousScanTapped(_ sender: Any) {
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(identifier: "ViewController") as? ViewController {
            scratchCode = ""
             self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    @IBAction func scanBtnTapped(_ sender: Any) {
        if let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(identifier: "ScanThroughPhotoViewController") as? ScanThroughPhotoViewController {
            scratchCode = ""
             self.navigationController?.pushViewController(vc, animated: true)
        }
       
    }
    
}
