//
//  ViewController.swift
//  ScanExample
//
//  Created by Aadhar Mathur on 25/11/19.
//  Copyright © 2019 Aadhar Mathur. All rights reserved.
//

import UIKit
import OCRScaniOS
import AVFoundation

extension UIImage {
    func detectOrientationDegree () -> CGFloat {
        switch imageOrientation {
        case .right, .rightMirrored:    return 90
        case .left, .leftMirrored:      return -90
        case .up, .upMirrored:          return 180
        case .down, .downMirrored:      return 0
        }
    }
}

class ViewController: UIViewController {
        // MARK: - Outlets
        @IBOutlet weak var cameraView: UIView!
    //    @IBOutlet weak var viewFinder: UIView!
        @IBOutlet weak var label: UILabel!
    var imageProcessing: Bool = false
    var settings: AVCapturePhotoSettings!
    @IBOutlet var btnTap: UIButton!
    
        // MARK: - Private Properties
        fileprivate var stillImageOutput: AVCapturePhotoOutput!
        fileprivate let captureSession = AVCaptureSession()
        fileprivate let device  = AVCaptureDevice.default(for: AVMediaType.video)
        private let ocrInstance = OCRScan()
        
        // MARK: - View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
                // start camera init
        DispatchQueue.global(qos: .userInitiated).async {
            if self.device != nil {
                self.configureCameraForUse()
            }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
       self.getCode()
    }
    override func viewWillDisappear(_ animated: Bool) {
         self.captureSession.stopRunning()
    }
    
    @IBAction func takePhotoButtonPressed (_ sender: UIButton) {
        
    }
    func getCode(){
        DispatchQueue.global(qos: .userInitiated).async {
    
            guard let capturedType = self.stillImageOutput.connection(with: AVMediaType.video) else {
                return
            }

            self.settings = AVCapturePhotoSettings()
//            settings.previewPhotoFormat = previewFormat
            self.stillImageOutput.capturePhoto(with: self.settings, delegate: self)
            self.settings = nil
        }
    }
    func sendToRecognizer(image : UIImage) {
        self.imageProcessing = true
        self.ocrInstance.recognize(image) { (text) in
            if text == "Wrong Input" {
                 self.settings = nil
                self.getCode()
            }
            else {
                scratchCode = text
                self.settings = nil
                DispatchQueue.main.async {
                   
                     self.navigationController?.popViewController(animated: true)
                }
               
            }
            self.imageProcessing = false
        }
    }
}
extension ViewController {
    // MARK: AVFoundation
    fileprivate func configureCameraForUse () {
        self.stillImageOutput = AVCapturePhotoOutput()
        let fullResolution = UIDevice.current.userInterfaceIdiom == .phone && max(UIScreen.main.bounds.size.width, UIScreen.main.bounds.size.height) < 568.0
        
        if fullResolution {
            self.captureSession.sessionPreset = AVCaptureSession.Preset.photo
        } else {
            self.captureSession.sessionPreset = AVCaptureSession.Preset.hd1280x720
        }
        
        self.captureSession.addOutput(self.stillImageOutput)
        
        DispatchQueue.global(qos: .userInitiated).async {
            self.prepareCaptureSession()
        }
    }
    
    private func prepareCaptureSession () {
        do {
            self.captureSession.addInput(try AVCaptureDeviceInput(device: self.device!))
        } catch {
            print("AVCaptureDeviceInput Error")
        }
        
        // layer customization
        DispatchQueue.main.async(execute: {
             let previewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
             previewLayer.frame.size = self.cameraView.frame.size
             previewLayer.frame.origin = CGPoint.zero
             previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
             
             // device lock is important to grab data correctly from image
             do {
                 try self.device?.lockForConfiguration()
                 self.device?.focusPointOfInterest = CGPoint(x: 0.5, y: 0.5)
                 self.device?.focusMode = .continuousAutoFocus
                 self.device?.unlockForConfiguration()
             } catch {
                 print("captureDevice?.lockForConfiguration() denied")
             }
             
             //Set initial Zoom scale
             do {
                 try self.device?.lockForConfiguration()
                 
                 let zoomScale: CGFloat = 2.5
                 
                if zoomScale <= (self.device?.activeFormat.videoMaxZoomFactor)! {
                    self.device?.videoZoomFactor = zoomScale
                 }
                 
                self.device?.unlockForConfiguration()
             } catch {
                 print("captureDevice?.lockForConfiguration() denied")
             }
                 self.cameraView.layer.addSublayer(previewLayer)
                 self.captureSession.startRunning()
        })
    }
    
    // MARK: Image Processing
    fileprivate func prepareImageForCrop (using image: UIImage) -> UIImage {
        let degreesToRadians: (CGFloat) -> CGFloat = {
            return $0 / 180.0 * CGFloat(Double.pi)
        }
        
        let imageOrientation = image.imageOrientation
        let degree = image.detectOrientationDegree()
        let cropSize = CGSize(width: 400, height: 110)
        
        //Downscale
        let cgImage = image.cgImage!
        
        let width = cropSize.width
        let height = image.size.height / image.size.width * cropSize.width
        
        let bitsPerComponent = cgImage.bitsPerComponent
        let bytesPerRow = cgImage.bytesPerRow
        let colorSpace = cgImage.colorSpace
        let bitmapInfo = cgImage.bitmapInfo
        
        let context = CGContext(data: nil,
                                width: Int(width),
                                height: Int(height),
                                bitsPerComponent: bitsPerComponent,
                                bytesPerRow: bytesPerRow,
                                space: colorSpace!,
                                bitmapInfo: bitmapInfo.rawValue)
        
        context!.interpolationQuality = CGInterpolationQuality.none
        // Rotate the image context
        context?.rotate(by: degreesToRadians(degree));
        // Now, draw the rotated/scaled image into the context
        context?.scaleBy(x: -1.0, y: -1.0)
        
        //Crop
        switch imageOrientation {
        case .right, .rightMirrored:
            context?.draw(cgImage, in: CGRect(x: -height, y: 0, width: height, height: width))
        case .left, .leftMirrored:
            context?.draw(cgImage, in: CGRect(x: 0, y: -width, width: height, height: width))
        case .up, .upMirrored:
            context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        case .down, .downMirrored:
            context?.draw(cgImage, in: CGRect(x: -width, y: -height, width: width, height: height))
        }
        
        let calculatedFrame = CGRect(x: 0, y: CGFloat((height - cropSize.height)/2.0), width: cropSize.width, height: cropSize.height)
        let scaledCGImage = context?.makeImage()?.cropping(to: calculatedFrame)
        
        
        return UIImage(cgImage: scaledCGImage!)
    }
    
}
extension ViewController :AVCapturePhotoCaptureDelegate {
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let imageData = photo.fileDataRepresentation()
        if let data = imageData, let img = UIImage(data: data) {
            if !self.imageProcessing {
                sendToRecognizer(image: img)
            }
        }
    }
}
