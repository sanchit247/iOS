protocol Chargable{
    
    // can not declare a stored property in protocol
    // var storeProp : Int = 3
    // not necessarly to be set optional
    var Not_StoredProperty : Int? {get}
    var computedProperty : String {get}
    var setableComputedProperty : String {get}
   func recharge()
}
extension Chargable where Self == ElectricVehicle{
    func recharge(){
        print("recharge from chargable extension for electric vehicle")
    }
}
protocol Fillable{
    func fillTank()
}
extension Fillable where Self == SportsVehicle{
    func fillTank(){
        print("fillTank from chargable extension for electric vehicle")
    }
}
protocol Drivable{
    func start()
    func stop()
    func park()
}
extension Drivable where Self == ElectricVehicle{
    func start() {
        print("start from extension")
    }
    
    func stop() {
        print("stop from extension")
    }
    
    func park() {
        print("park from extension")
    }
}
struct ElectricVehicle : Drivable,Chargable{
    fileprivate var name : String
    var setableComputedProperty: String {
        get{
            return "getting setable computed property \(name)"
        }
        set{
            name  = newValue
        }
    }
    
    var computedProperty: String {
        return "computed property \(Not_StoredProperty!)"
    }
    
    var Not_StoredProperty: Int? = 1
    
    init() {
        print("Electric Vehicle init")
        name = "abcd"
    }
}

struct SportsVehicle : Drivable, Fillable{
    func start() {
        print("start from sportsVehicle")
    }
    
    func stop() {
        print("stop from sportsVehicle")
    }
    
    func park() {
        print("park from sportsVehicle")
    }
}

struct Bucket : Fillable{
    func fillTank() {
        print("fill tank from bucket")
    }
}

var electricObj : ElectricVehicle = ElectricVehicle()
electricObj.start()
electricObj.recharge()
print(electricObj.Not_StoredProperty!)
// stored property is of get type still we can set it because object is  of ElectricVehicle
print(electricObj.computedProperty)
print(electricObj.name)
print(electricObj.setableComputedProperty)
electricObj.setableComputedProperty = "name"
print(electricObj.name)

var chargableObj : Chargable = ElectricVehicle()
// since chargableobj is od Chargable we can not set a value to a get type
//chargableObj.storedProperty = 3
let sportsOBj : SportsVehicle = SportsVehicle()
